package floristeriaa;

public class floristeriaa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Casa andresCasa= new Casa("Blanca con gris",3,2,false,true);
		System.out.println(andresCasa.describir());
	}

}
